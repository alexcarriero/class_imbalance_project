
# data generation --------------------------------------------------------------

generate_data <- function(inn, test = FALSE){
  
  npred   = inn[[1]]
  ev      = inn[[2]]
  n.level = inn[[3]]
  n       = inn[[4]]
  mu0     = inn[[5]]
  mu1     = inn[[6]]
  sigma0  = inn[[7]]
  sigma1  = inn[[8]]
  
  # test set
  if (test == TRUE){n  = n*10}
  
  # positive class
  n1      <- rbinom(1, n, ev)
  class_1 <- mvrnorm(n1, mu1, sigma1)
  
  # negative class
  n0      <- n - n1
  class_0 <- mvrnorm(n0, mu0, sigma0)
  
  outcome <- c(rep(1, n1), rep(0, n0))
  
  # format data frame
  df <- cbind(outcome, rbind(class_1, class_0)) %>% 
    as.data.frame() %>% 
    mutate(outcome = as.factor(outcome))
  
  # names
  colnames(df) <- c("outcome", paste0("x", 1:npred))
  
  return(df)
}


# class imbalance corrections --------------------------------------------------


do_rus <- function(dataframe){
  
  message <- 0
  count   <- 0
  warn    <- 0
  formula <- outcome~.
  data    <- dataframe
  
  df.rus <- 
      tryCatch.W.E(
        expr = {
          df.rus <- ovun.sample(formula, data, method = "under")$data
        }
      )
  
  if(is.data.frame(df.rus$value) == TRUE){
    c_data  <- df.rus$value
  } else{
    message <- as.character(df.rus$value)
    count   <- 1
    c_data  <- dataframe
  }
  
  warn <- as.character(df.rus$warning)
  out  <- list("c_dataframe" = c_data, "correction_err" = message, "count_err" = count, "correction_warning" = warn)
  return(out)
}

do_ros <- function(dataframe){
    
  message <- 0
  count   <- 0
  warn    <- 0
  formula <- outcome~.
  data    <- dataframe
    
    df.ros <- 
      tryCatch.W.E(
        expr = {
          df.ros <-  ovun.sample(formula, data, method = "over")$data
        }
      )
    if(is.data.frame(df.ros$value) == TRUE){
      c_data  <- df.ros$value
    } else{
      message <- as.character(df.ros$value)
      count   <- 1
      c_data  <- dataframe
    }
    
    warn <- as.character(df.ros$warning)
    out  <- list("c_dataframe" = c_data, "correction_err" = message, "count_err" = count, "correction_warning" = warn)
    return(out)
}

do_smo <- function(df, percOver, k = 5){
  
  message <- 0
  count   <- 0
  warn    <- 0
  
  df.smote <- 
    tryCatch.W.E(
      expr = {
        df.smote <- SMOTE(x = df[-1], y = df[1], percOver, k)
      }
    )
  if(is.data.frame(df.smote$value) == TRUE){
    c_data  <- df.smote$value %>% relocate("outcome")
  } else{
    message <- as.character(df.smote$value)
    count   <- 1
    c_data  <- df
  }
  
  warn <- as.character(df.smote$warning)
  out  <- list("c_dataframe" = c_data, "correction_err" = message, "count_err" = count, "correction_warning" = warn)
  return(out)
}

do_sen <- function(df, percOver, k1 = 5, k2 = 3){
  
  message <- 0
  count   <- 0
  warn    <- 0
  
  df.smote.enn <- 
    tryCatch.W.E(
      expr = {
        df.smote.enn <- SmoteENN(x = df[-1], y = df[1], percOver, k1, k2)
      }
    )
  if(is.data.frame(df.smote.enn$value) == TRUE){
    c_data  <- df.smote.enn$value %>% relocate("outcome")
  } else{
    message <- as.character(df.smote.enn$value)
    count   <- 1
    c_data  <- df
  }
  
  warn <- as.character(df.smote.enn$warning)
  out  <- list("c_dataframe" = c_data, "correction_err" = message, "count_err" = count, "correction_warning" = warn)
  return(out)
}


# model implementation ---------------------------------------------------------

do_lrg <- function(df, test, iter, s){
  
  error       <- 0
  warning     <- 0
  problematic <- 0
  
  # ensure correct factor levels 
  df$outcome  <- factor(df$outcome, levels=c(0,1), ordered = TRUE)
  
  # model 
  a <- tryCatch.W.E(
    expr    = { 
      set.seed(s)
      mod  <- glm( outcome~., family = "binomial", data = df)
      pred <- predict(mod,  newdata = test, type = "response")
    }
  )
  
  # sort predictions and errors
  if (is.vector(a$value) == FALSE){
    pred  <- NA
    error <- a$value
    problematic <- 1
  } else{
    pred <- a$value
  }
  
  # sort warnings
  if(is.null(a$warning) == FALSE){
    warning <- a$warning
    problematic <- 1
  }
  
  # output 
  pred   <- cbind(pred, "iter" = iter, "class" = as.numeric(test$outcome) - 1, "problem" = problematic)
  output <- list("pred" = pred, "warning" = warning, "error" = error, "problem" = problematic)
  return(output)
}


deviance <- function(data, lev = NULL, model = NULL) {
  obs  <- as.numeric(data$obs) - 1
  pred <- data$one
  
  pred[pred == 0] <- 1e-16
  pred[pred == 1] <- 1-1e-16
  
  dev <- -2*sum(obs*log(pred) + (1-obs)*log(1-pred))
  
  c(Deviance = dev)
}


do_svm <- function(df, test, iter, s){
  
  error       <- 0
  warning     <- 0
  problematic <- 0
  
  # ensure correct factor levels, and character labels 
  df$outcome     = factor(df$outcome, levels=c(0,1), ordered = TRUE)
  
  # model
  a <- tryCatch.W.E(
    expr    = { 
      set.seed(s)
      levels(df$outcome) <- c("zero", "one")
      
      train_ctrl <- 
        trainControl(
          method = "cv", 
          number = 5, 
          summaryFunction = deviance, 
          classProbs = T,
          allowParallel = F
      )
      
      mod <- 
        train(
          outcome ~., 
          data = df, 
          method = "svmRadial", 
          metric = "Deviance",
          maximize = FALSE, 
          trControl = train_ctrl,
          preProcess = c("center", "scale"), 
          tuneLength = 3
      ) 
      
      pred <- predict(mod, newdata = test, type = "prob")["one"]
      colnames(pred) <- "pred"
      pred <- pred
    }
  )
  
  # sort predictions and errors
  if (is.data.frame(a$value) == FALSE){
    pred  <- NA
    error <- a$value
    problematic <- 1
  } else{
    pred <- a$value
  }
  
  # sort warnings
  if(is.null(a$warning) == FALSE){
    warning <- a$warning
    problematic <- 1
  }
  
  # output 
  pred   <- cbind(pred, "iter" = iter, "class" = as.numeric(test$outcome) - 1, "problem" = problematic)
  output <- list("pred" = pred, "warning" = warning, "error" = error, "problem" = problematic)
  return(output)
}


do_rnf <- function(df, test, iter, s){
  
  error       <- 0
  warning     <- 0
  problematic <- 0
  
  # ensure correct factor levels, and character labels 
  df$outcome     = factor(df$outcome, levels=c(0,1), ordered = TRUE)
  
  # model
  a <- tryCatch.W.E(
    expr    = { 
      set.seed(s)
      npred = dim(df)[2] -1 
      levels(df$outcome) <- c("zero", "one")
      
      train_ctrl <- 
        trainControl(
          method = "cv", 
          number = 5, 
          summaryFunction = deviance, 
          classProbs = T,
          allowParallel = F
      )
      
      mod <- 
        train(
          outcome ~., 
          data = df, 
          method = "ranger", 
          metric = "Deviance",
          maximize = FALSE, 
          trControl = train_ctrl,  
          tuneGrid = 
            expand.grid(
              mtry = 1:npred,
              min.node.size = 1:10,
              splitrule = "gini"
              )
      )    
      
      pred <- predict(mod, newdata = test, type = "prob")["one"]
      colnames(pred) <- "pred"
      pred <- pred
    }
  )
  
  # sort predictions and errors
  if (is.data.frame(a$value) == FALSE){
    pred  <- NA
    error <- a$value
    problematic <- 1
  } else{
    pred <- a$value
  }
  
  # sort warnings
  if(is.null(a$warning) == FALSE){
    warning <- a$warning
    problematic <- 1
  }
  
  # output 
  pred   <- cbind(pred, "iter" = iter, "class" = as.numeric(test$outcome) - 1, "problem" = problematic)
  output <- list("pred" = pred, "warning" = warning, "error" = error, "problem" = problematic)
  return(output)
}


do_xgb <- function(df, test, iter, s){
  
  error       <- 0
  warning     <- 0
  problematic <- 0
  
  # ensure correct factor levels, and character labels 
  df$outcome     = factor(df$outcome, levels=c(0,1), ordered = TRUE)
  
  # model
  a <- tryCatch.W.E(
    expr    = { 
      set.seed(s)
      levels(df$outcome) <- c("zero", "one")
      
      train_ctrl <- 
        trainControl(
          method = "cv", 
          number = 5, 
          summaryFunction = deviance, 
          classProbs = T,
          allowParallel = F
      )
      
      mod <- 
        train(
          outcome ~., 
          data = df, 
          method = "xgbTree", 
          metric = "Deviance",
          maximize = FALSE, 
          trControl = train_ctrl, 
          verbosity = 0, 
          verbose = FALSE, 
          tuneLength = 3
      )
      
      pred <- predict(mod, newdata = test, type = "prob")["one"]
      colnames(pred) <- "pred"
      pred <- pred
    }
  )
  
  # sort predictions and errors
  if (is.data.frame(a$value) == FALSE){
    pred  <- NA
    error <- a$value
    problematic <- 1
  } else{
    pred <- a$value
  }
  
  # sort warnings
  if(is.null(a$warning) == FALSE){
    warning <- a$warning
    problematic <- 1
  }
  
  # output 
  pred   <- cbind(pred, "iter" = iter, "class" = as.numeric(test$outcome) - 1, "problem" = problematic)
  output <- list("pred" = pred, "warning" = warning, "error" = error, "problem" = problematic)
  return(output)
}


do_rub <- function(df, test, iter, s){
  
  error       <- 0
  warning     <- 0
  problematic <- 0
  
  # ensure correct levels of the factors
  df$outcome = factor(df$outcome, levels=c(0,1), ordered = TRUE)
  
  # model 
  a <- tryCatch.W.E(
    expr    = { 
      set.seed(s)
      mod  <- rus(outcome ~., size = 10, alg = "svm", data = df, svm.ker = "radial")
      pred <- predict(mod, newdata = test)
    }
  )
  
  # sort predictions and errors
  if (is.vector(a$value) == FALSE){
    pred  <- NA
    error <- a$value
    problematic <- 1
  } else{
    pred <- a$value
  }
  
  # sort warnings
  if(is.null(a$warning) == FALSE){
    warning <- a$warning
    problematic <- 1
  }
  
  # output 
  pred   <- cbind(pred, "iter" = iter, "class" = as.numeric(test$outcome) - 1, "problem" = problematic)
  output <- list("pred" = pred, "warning" = warning, "error" = error, "problem" = problematic)
  return(output)
}


do_eas <- function(df, test, iter, s){
  
  error       <- 0
  warning     <- 0
  problematic <- 0
  
  # model 
  a <- tryCatch.W.E(
    expr    = { 
      set.seed(s)
      train_x <- df %>% dplyr::select(-outcome)
      train_y <- df %>% dplyr::pull(outcome)
      test_x  <- test %>% dplyr::select(-outcome)
      
      mod  <- EasyEnsemble(train_x, train_y)
      pred <- predict(mod, test_x, type = "probability")$X1
    }
  )
  
  # sort predictions and errors
  if (is.vector(a$value) == FALSE){
    pred  <- NA
    error <- a$value
    problematic <- 1
  } else{
    pred <- a$value
  }
  
  # sort warnings
  if(is.null(a$warning) == FALSE){
    warning <- a$warning
    problematic <- 1
  }
  
  # output 
  pred   <- cbind(pred, "iter" = iter, "class" = as.numeric(test$outcome) - 1, "problem" = problematic)
  output <- list("pred" = pred, "warning" = warning, "error" = error, "problem" = problematic)
  return(output)

}

# performance metrics ----------------------------------------------------------

auroc <- function (probs, outcome){
  if(any(is.na(probs)) == TRUE){
    return(NA)
  }
  
  if(is.numeric(outcome) == FALSE) {outcome <- as.numeric(outcome) - 1}

  auc  <- as.numeric(pROC::roc(outcome~probs, quiet = TRUE)$auc)
  
  return(auc)
}

scaled_brier_score <- function(probs, outcome){
  if(any(is.na(probs)) == TRUE){
    return(NA)
  }
  
  if(is.numeric(outcome) == FALSE) {outcome <- as.numeric(outcome) - 1}
  
  obs       = outcome
  unscaled  = mean((probs - obs)^2)
  brier_max = mean(obs)*(1 - mean(obs))
  scaled    = 1 - (unscaled / brier_max)
  
  return(scaled)
}
  
calibration_intercept <- function(probs, outcome){
  if(any(is.na(probs)) == TRUE){
    return(NA)
  }
  if(sum(probs == 1) != 0){
    probs[probs == 1] <- 1 - 1e-10
  }
  if(sum(probs == 0) != 0){
    probs[probs == 0] <- 1e-10
  }
  mod <- glm(outcome ~ 1, offset = log(probs/(1-probs)), family = "binomial")
  int <- coef(mod)[1]
  return(int)
}

calibration_slope <- function(probs, outcome){
  if(any(is.na(probs)) == TRUE){
    return(NA)
  }
  if(sum(probs == 1) != 0){
    probs[probs == 1] <- 1 - 1e-10
  }
  if(sum(probs == 0) != 0){
    probs[probs == 0] <- 1e-10
  }
  mod <- glm(outcome ~ log(probs/(1-probs)), family = "binomial")
  slp <- coef(mod)[2]
  return(slp)
}

performance_statistics <- function(pred, class){
  # catch algorithms that give invalid probabilities
  garbage_below_0 <- 0
  garbage_above_1 <- 0
  
  if(any(is.na(pred)) == FALSE & any(pred < 0) == TRUE){
    pred[pred < 0 ] <- 1e-10
    garbage_below_0 <- 1
  }
  if(any(is.na(pred)) == FALSE & any(pred > 1) == TRUE){
    pred[pred > 1 ] <- 1 - 1e-10
    garbage_above_1 <- 1
  }
  
  # catch warnings from glms estimating calibration int and slp
  c_int = tryCatch.W.E(expr = {calibration_intercept(pred, class)})
  c_slp = tryCatch.W.E(expr = {calibration_slope(pred,class)})
  
  return(
    tibble(
      min = min(pred),
      max = max(pred),
      var = var(pred),
      auc = auroc(pred, class),
      bri = scaled_brier_score(pred, class), 
      int = as.character(c_int$value), 
      slp = as.character(c_slp$value),
      int_warn  = ifelse(is.null(c_int$warning), "0", as.character(c_int$warning)),
      int_count = ifelse(is.null(c_int$warning), "0" , "1"),
      slp_warn  = ifelse(is.null(c_slp$warning), "0", as.character(c_slp$warning)), 
      slp_count = ifelse(is.null(c_slp$warning), "0" , "1"), 
      invalid_0 = garbage_below_0, 
      invalid_1 = garbage_above_1
    )
  )
}

get_stats <- function(dataframe){
    pm <- 
      dataframe %>%
      mutate(pair_id  = as.factor(pair_id),
             class    = as.factor(class), 
             pred     = as.numeric(pred)) %>%
      group_by(pair_id) %>%
      group_modify(~performance_statistics(pred = .x$pred, class = .x$class))
    
    return(pm)
}

get_stats_recalibrated <- function(dataframe){
  pm <- 
    dataframe %>%
    mutate(pair_id  = as.factor(pair_id),
           class    = as.factor(class), 
           pred     = as.numeric(pred)) %>%
    group_by(pair_id) %>%
    group_modify(~performance_statistics(pred = .x$pred, class = .x$class)) %>% 
    mutate(recalibrated = 1, 
           recal_warn = r_warn)
  
  return(pm)
}

# --------------- simulation set up --------------------------------------------
  
algorithms   <- c("logistic_regression", "support_vector_machine", "random_forest", "xgboost", "rusboost", "easy_ensemble")
corrections  <- c("control", "rus", "ros", "smo", "sen")

pairs <- 
  expand_grid(corrections, algorithms) %>% 
  mutate(pair_id = c(1:30)) %>% 
  relocate(pair_id)

# --------------- simulation code ----------------------------------------------

sim_in_series<- function(scenario, start, stop){
  
  # set up 
  sc    <- scenario
  input <- set[[sc]]
  
  # simulation
  for (i in start:stop){
  
    # storage
    checks = c()
    out    = c()
    info   = c()
  
    # simulation
    for (p in 1:30){
      
      # set seed
      seed <- pull(seed.farm[sc])[i]
      set.seed(seed)
      
      # train and test data
      df <- generate_data(input)
      tf <- generate_data(input, test = TRUE)
      ef <- mean(as.numeric(df$outcome)-1)
      
      # pair set up
      pair_id    <- as.character(pairs[p,1])
      correction <- as.character(pairs[p,2])
      algorithm  <- as.character(pairs[p,3])
      
      # calculate percent over sample needed to balance
      if (ef < 0.5){
        percO <- (1/ef - 1/0.5)*100
      } else{
        temp_ef <- 1-ef
        percO <- (1/temp_ef - 1/0.5)*100
      }
      
      # store last value of first predictor for reproducibility check
      df_i  <- pull(df[2])[nrow(df)] 
      tf_i  <- pull(tf[2])[nrow(df)]
    
      # pre-process step 
      if (correction != "control"){
        if(correction == "rus"){ crr <- do_rus(df) }
        if(correction == "ros"){ crr <- do_ros(df) }
        if(correction == "smo"){ crr <- do_smo(df, percO) }
        if(correction == "sen"){ crr <- do_sen(df, percO) }
        
        # save corrected data
        df <- crr$c_dataframe
      }
      
      # save last value of first predictor of corrected data frame for reproducibility check
      crr_df_i  <- pull(df[2])[nrow(df)]
      check_i <- cbind("dataframe" = df_i, "testframe" = tf_i, "c_dataframe" = crr_df_i, "iter" = i, "pair_id" = p, "scenario" = sc)
      checks  <- rbind(checks, check_i) 
    
      # implement algorithm 
      if(algorithm == "logistic_regression")   { alg <- do_lrg(df, tf, i, seed) }
      if(algorithm == "support_vector_machine"){ alg <- do_svm(df, tf, i, seed) }
      if(algorithm == "random_forest")         { alg <- do_rnf(df, tf, i, seed) }
      if(algorithm == "xgboost")               { alg <- do_xgb(df, tf, i, seed) }
      if(algorithm == "rusboost")              { alg <- do_rub(df, tf, i, seed) }
      if(algorithm == "easy_ensemble")         { alg <- do_eas(df, tf, i, seed) }
    
      # save iteration information
      iter_info <- 
        cbind(
          "scenario"   = sc,
          "pair_id"    = p,
          "correction" = correction,
          "algorithm"  = algorithm, 
          "iter"       = i,
          "seed"       = seed, 
          "sc_ef"      = input$event_frac,
          "obs_ef"     = round(ef, 3),
          "new_ef"     = round(mean(as.numeric(df$outcome)-1), 3),
          "c_problem"  = ifelse(correction == "control", "0", crr$count_err),
          "c_warn"     = ifelse(correction == "control", "0", crr$correction_warning),
          "c_err"      = ifelse(correction == "control", "0", crr$correction_err),
          "a_problem"  = alg$problem,
          "a_warning"  = as.character(alg$warning), 
          "a_err"      = as.character(alg$error)
        )
    
      # save predictions
      pred  <- 
        cbind(
          alg$pred, 
          "scenario"   = sc, 
          "pair_id"    = p, 
          "correction" = correction, 
          "algorithm"  = algorithm
        )
      
      out   <- rbind(out, pred)        # predictions
      info  <- rbind(info, iter_info)  # iteration info
      print(p)
    }

  
  # save corrected data frames
  checks  <- as.data.frame(checks)  %>% `rownames<-`( NULL )
  saveRDS(checks, file = paste0("sim_results/rep_checks/sc", sc, "_", i ,".rds"))
  
  # save predicted probabilities
  out  <- as.data.frame(out)  %>% `rownames<-`( NULL )
  saveRDS(out, file = paste0("sim_results/predictions/sc", sc, "_", i ,".rds"))
  
  # save iteration info
  info <- as.data.frame(info) %>% `rownames<-`( NULL )
  saveRDS(info, file = paste0("sim_results/iteration_info/sc", sc, "_", i,  ".rds"))
  
  # save per iteration results
  results <- get_stats(out) 
  results <- merge(info, results, by = "pair_id")
  saveRDS(results, paste0("sim_results/per_iter_results/sc", sc, "_", i,".rds"))
  }
}
